

// const axios = require('axios');

// async function getCurrencyData() {
//     try {
//         const response = await axios.post('https://api.nobitex.ir/market/global-stats');
//         return response.data.markets.binance;
//     } catch (error) {
//         console.error('Error fetching currency data:', error);
//         throw error;
//     }
// }

// module.exports = {
//     getCurrencyData
// };
